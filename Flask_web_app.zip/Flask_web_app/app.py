from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    # You can run your python logic here and pass data to the template
    script_output = "Hello from the Flask server!"
    return render_template('index.html', output=script_output)

if __name__ == '__main__':
    app.run(debug=True)
